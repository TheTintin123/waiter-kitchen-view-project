import {Injectable} from "@angular/core";
import {ActivatedRouteSnapshot, CanActivate, provideRoutes, Router, RouterStateSnapshot} from "@angular/router";
import {HttpClient} from "@angular/common/http";
import {DbService} from "./db.service";
import {catchError, map, of} from "rxjs";

@Injectable({
  providedIn: "root"
})
export class LoginGuardian implements CanActivate {
  constructor(private router:Router, private httpClient:HttpClient, private dbService:DbService) {
    this.dbService = new DbService(this.httpClient)
  }

  //Schickt Anfrage an db.service.ts um den JWT auf dem Server zu verifizieren
  //Wenn die Verifizierung erfolgreich war, wird der User anhand seiner Rolle zum jeweiligen View weitergeleitet
  //Bei Fehler wird der User zum Login (kein/falscher JWT) oder zu seinem jeweiligen Dashboard weitergeleitet
  canActivate(route: ActivatedRouteSnapshot){
    return this.dbService.checkTokenValidity()
      .pipe(
        map((data) => {
          let currentRoute = route.routeConfig?.path;
          if((currentRoute === "overview" || currentRoute === "incomplete" || currentRoute === "consult" || currentRoute === "orders" || currentRoute === "readyItems") && data.role === 'Waiter')
            return true;
          else if((currentRoute === "overview2" || currentRoute === "menuItems" || currentRoute === "orders2cook" || currentRoute === "itemSequence") && data.role === 'Kitchen')
            return true;
          else
            if(data.role === 'Kitchen')
              this.router.navigate(["dashboard2"]);
            else
              this.router.navigate(["dashboard"])
            console.log("You are not allowed there!")
            return false
        }),
        catchError((error) => {
          console.log(error);
          this.router.navigate([""]);
          return of(false);
        })
      )
  }
}
