import { Component, OnInit } from '@angular/core';
import {items, orders} from "../orders/orders.component";
import {DbService} from "../../db.service";


@Component({
  selector: 'app-incomplete',
  templateUrl: './incomplete.component.html',
  styleUrls: ['./incomplete.component.css']
})
export class IncompleteComponent implements OnInit {

  items!: items[];
  orders!: orders[];
  itemsData!: items[];
  ordersData!: orders[];
  panelOpenState = false;
  itemCounter: number = 0;


  constructor(private dbService: DbService) {
  }

  //Beim Laden der Seite werden zuerst die Items und dann die Orders aus der DB geholt
  ngOnInit(): void {
    this.dbGetItems().then(data => {
      console.log(data);
      this.dbGetOrders()
    })
  }

  //Schickt Anfrage an db.service.ts um Items aus der DB zu holen
  dbGetItems(){
    return new Promise(resolve => {
      this.dbService.getOrderedItems().subscribe((i: items[]) => {
        this.items = i;
        this.itemsData = i.filter(x => x.status === 'readyForPickup' || x.status === 'inTransit' || x.status === 'delivered');
        resolve("Got all items!")
      })
    })
  }

  //Schickt Anfrage an db.service.ts um Orders aus der DB zu holen
  dbGetOrders(){
    this.dbService.getOrders().subscribe((i: orders[]) => {
      i.forEach(x => this.checkOrderState(x));
     this.ordersData = i.filter(x => x.status === 'incomplete');
    });
  }

  //Überprüft bei jeder Orden den Status und ändert ihn gegebenfalls
  checkOrderState(currentOrder: any) {
    let currentStatus: string = "ordered";
    let orderedItemsCounter: number = 0;
    let deliveredItemsCounter: number = 0;
    for (let i = 0; i < this.items.length; i++) {
      if (this.items[i].orderid == currentOrder.orderid) {
        orderedItemsCounter++;
        if (this.items[i].status == "readyForPickup" || this.items[i].status == "inTransit") {
          currentStatus = "incomplete";
          break;
        } else if (this.items[i].status == "delivered")
          deliveredItemsCounter++;
      }
    }
      if(deliveredItemsCounter > 0)
        currentStatus = 'incomplete';
      if (deliveredItemsCounter == orderedItemsCounter)
        currentStatus = 'complete';
      currentOrder.status = currentStatus;
      this.dbService.updateOrderStatus(currentOrder).subscribe((i: orders) => {
        console.log(i);
      })
  }

  //Überprüft ob der Button InTransit disabled ist oder nicht
  //Wenn das Item delivered ist, ist er auch disabled
  buttonState1(currentElement: any):boolean{
    return currentElement.status == "inTransit" || currentElement.status == "delivered";
  }

  //Überprüft ob der Button Delivered disabled ist oder nicht
  buttonState2(currentElement: any):boolean{
    return currentElement.status == "delivered";
  }

  //Auf Knopfdruck wird eine Funktion in der db.service.ts aufgerufen, die den Status des jeweiligen Items in der DB ändert
  //Gleichzeitig werden die Items und Orders neu geladen
  updateStatus(button: number, currentElement: any) {
    if (button == 1)
      currentElement.status = "delivered"
    else
      currentElement.status = "inTransit"

    this.itemCounter++;
    this.dbService.updateOrderedItemStatus(currentElement).subscribe((i: items) => {
      console.log(i);
    })
    if (button == 1) {
      setTimeout(()=>{
        this.dbGetItems().then(data => {
          console.log(data);
          this.dbGetOrders();
        });
      },300)
    }
  }
}
