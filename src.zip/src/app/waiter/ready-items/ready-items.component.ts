import {Component, OnInit, ViewChild} from '@angular/core';
import {DbService} from "../../db.service";
import {interval} from "rxjs";
import {MatTable} from "@angular/material/table";

export interface readyItems{
  orderId: number;
  itemName: string;
  tableId: number;
  status: string;
}

@Component({
  selector: 'app-ready-items',
  templateUrl: './ready-items.component.html',
  styleUrls: ['./ready-items.component.css']
})
export class ReadyItemsComponent implements OnInit {

  itemsData!: readyItems[];
  oldLength: number = 0;
  counter:number = 0;
  sec:any;
  onActive:boolean = false;

  @ViewChild(MatTable) myTable!: MatTable<any>;

  constructor(private dbService: DbService) {}

  //Beim Laden werden die Items aus der DB geholt und onActive auf true gesetzt
  ngOnInit(): void {
    this.dbGetItems().then( data => {
      console.log(data)
    })
    this.onActive = true;
  }

  displayedColumns: string[] = ["orderId", "title", "tableid"];

  //Überprüft nach jeweils 5 sec, ob einen Änderung bei den ReadyItems stattgefunden hat
  //Ist ein ReadyItem dazugekommen wird die Push-Notification aufgerufen
 checkAfterInterval() {
      this.sec = interval(5000).subscribe(e => {
        console.log(e)
        this.dbGetItems().then(data => {
          console.log(data);
          if (this.itemsData.length !== 0 && this.itemsData.length > this.oldLength) {
            this.oldLength = this.itemsData.length;
            console.log("Found something new!")
            this.showNotification();
            if(this.onActive)
              this.updateTable();
          } else
            this.oldLength = this.itemsData.length;
        })
      })
  }

  //Stoppt das Intervall
  destroyChecker(){
    this.sec.unsubscribe();
  }

  //Schickt Anfrage an db.service.ts um ReadyItems aus der DB zu holen
  dbGetItems(){
    return new Promise((resolve) => {
      this.dbService.getReadyItems().subscribe((i: readyItems[]) => {
        this.itemsData = i.filter(x => x.status === 'readyForPickup');
        resolve("Items loaded")
      });
    })
  }

  //Refreshed den Table
  updateTable(){
    this.myTable.renderRows();
  }

  //Gibt eine Push-Notification aus
  showNotification(){
    const noti = new Notification("New Items are ready for PickUp",{
      icon: "https://campus.aau.at/vk/visitenkartenimage/image/-772243224"
    })
  }

}
