import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadyItemsComponent } from './ready-items.component';

describe('ReadyItemsComponent', () => {
  let component: ReadyItemsComponent;
  let fixture: ComponentFixture<ReadyItemsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReadyItemsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadyItemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
