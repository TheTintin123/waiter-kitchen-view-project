import { Component, OnInit } from '@angular/core';
import {DbService} from "../../db.service";

export interface orders{
  orderid: number;
  tableid: number;
  status: string;
}

export interface items{
  itemid: string;
  title: string;
  orderid: number;
  comment: string;
  status: string;
}

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

  itemsData!: items[];
  ordersData!: orders[];
  panelOpenState = false;

  constructor(private dbService: DbService) {
  }

  //Beim Laden der Seite werden die beiden Get-Funktionen aufgerufen
  ngOnInit(): void {
    this.dbGetItems();
    this.dbGetOrders();
  }

  //Schickt Anfrage an db.service.ts um Items aus der DB zu holen
  dbGetItems() {
    this.dbService.getOrderedItems().subscribe((i: items[]) => {
      this.itemsData = i;
    });
  }

  //Schickt Anfrage an db.service.ts um Orders aus der DB zu holen
  dbGetOrders() {
    this.dbService.getOrders().subscribe((i: orders[]) => {
      this.ordersData = i.filter(x => x.status === 'complete')
    });
  }
}
