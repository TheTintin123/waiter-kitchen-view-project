import {Component, OnInit, ViewChild} from '@angular/core';
import {DbService} from "../../db.service";
import {MatTable} from "@angular/material/table";

export interface consultations {
  status: string;
  consulid: number,
  tableid: number
}

@Component({
  selector: 'app-consult',
  templateUrl: './consult.component.html',
  styleUrls: ['./consult.component.css']
})
export class ConsultComponent implements OnInit {


  consulData!: consultations[];

  constructor(private dbService: DbService) {
  }

  //Beim Laden der Seite wird die Get-Consultationsfunktion aufgerufen
  ngOnInit(): void {
    this.dbGetConsultations();
  }

  //Schickt Anfrage an db.service.ts um Consultations aus der DB zu holen
  dbGetConsultations() {
    this.dbService.getConsultations().subscribe((i: consultations[]) => {
      this.consulData = i;
    });
  }

  //Schickt Anfrage an db.service.ts um Consultations aus der DB zu löschen
  //gleichzeitig werden neue Consultations aus der DB geholt und der Table refreshed
  deleteConsultation(currentConsul: consultations){
    console.log(currentConsul)
    this.dbService.deleteConsultation(currentConsul).subscribe((i:consultations) => {
      console.log(i);
    })
    this.dbGetConsultations();
    this.updateTable();
  }

  @ViewChild(MatTable) myTable!: MatTable<any>;

  //Refreshed den Table
  updateTable(){
    this.myTable.renderRows();
  }

  displayedColumns: string[] = ["consulid", "status", "tableid","progress"];
}
