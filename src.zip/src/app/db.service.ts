import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import {category, hasCategory, menuItems} from "./kitchen/menu-items/menu-items.component";
import {items, orders} from "./waiter/orders/orders.component";
import {readyItems} from "./waiter/ready-items/ready-items.component";
import {consultations} from "./waiter/consult/consult.component";
import {User} from "./login/login.component";

@Injectable({
  providedIn: "root"
})

//Stellt Verbindung zur Datenbank her und fragt die einzelenen Pfade ab
export class DbService{
  baseURL: string = "http://localhost:3000";

  constructor(private http: HttpClient) {}

  //Authentication
  //Überprüft ob User und Password so in der DB sind
  getLoginUser(userCredential: User): Observable<any>{
    return this.http.get<any>(this.baseURL + "/login/" + userCredential.username + "/" + userCredential.password)
  }

  //Lässt sich anhand des Namens, Passwords und der Rolle einen JWT erstellen
  requestToken(userCredentials: User): Observable<any>{
    const url = this.baseURL + "/auth/login";
    const headers = new HttpHeaders().set('content-type', "application/json").set('authorization', 'Bearer ' + sessionStorage.getItem("userToken"));
    return this.http.post<any>(url, JSON.stringify(userCredentials), {headers: headers});
  }

  //Überprüft den Token am Server
  checkTokenValidity(): Observable<any>{
    const url = this.baseURL + "/auth/authenticate";
    const headers = new HttpHeaders().set('content-type', "application/json").set('authorization', 'Bearer ' + sessionStorage.getItem("userToken"));
    return this.http.post<any>(url, JSON.stringify({accessToken: sessionStorage.getItem("userToken")!}), {headers: headers})
  }

  //Holt alle MenuItems aus der DB
  getItems(): Observable<menuItems[]>{
    return this.http.get<menuItems[]>(this.baseURL+"/menuItems");
  }

  //Aktualisiert den Status der MenuItems (available/not available)
  updateMenuItemStatus(updateItem: menuItems): Observable<menuItems>{
    const url = this.baseURL + "/menuItem/status/" + updateItem.id;
    const headers = new HttpHeaders().set("content-type","application/json");
    return this.http.put<menuItems>(url, JSON.stringify(updateItem), {headers: headers})
  }

  //Holt alle OrderedItems aus der DB
  getOrderedItems(): Observable<items[]>{
    return this.http.get<items[]>(this.baseURL+"/orderedItems");
  }

  //Holt alle ReadyItems aus der DB
  getReadyItems(): Observable<readyItems[]>{
    return this.http.get<readyItems[]>(this.baseURL+"/readyItems");
  }

  //Holt alle Orders aus der DB
  getOrders(): Observable<orders[]>{
    return this.http.get<orders[]>(this.baseURL+"/orders");
  }

  //Holt alle Consultations aus der DB
  getConsultations(): Observable<consultations[]>{
    return this.http.get<consultations[]>(this.baseURL+"/consultations");
  }

  //Holt alle Kategorien aus der DB
  getCategories(): Observable<category[]>{
    return this.http.get<category[]>(this.baseURL+"/kitchen/categories");
  }

  //Holt eine Liste von item_hasCategory aus der DB
  getHasCategoryList(): Observable<hasCategory[]>{
    return this.http.get<hasCategory[]>(this.baseURL+"/hasCategory");
  }

  //Aktualisiert den Status der OrderedItems (ordered/inProduction/ReadyForPickup/inTransit/Delivered)
  updateOrderedItemStatus(updateItem: items): Observable<items>{
    const url = this.baseURL + "/orderedItem/status/" + updateItem.itemid;
    const headers = new HttpHeaders().set("content-type","application/json");
    return this.http.put<items>(url, JSON.stringify(updateItem), {headers: headers})
  }

  //Aktualisiert den Comment der OrderedItems
  updateOrderedItemComment(updateItem: items): Observable<items>{
    const url = this.baseURL + "/orderedItem/comment/" + updateItem.itemid;
    const headers = new HttpHeaders().set("content-type","application/json");
    return this.http.put<items>(url, JSON.stringify(updateItem), {headers: headers})
  }

  //Aktualisiert den Status der Orders (ordered/incomplete/complete)
  updateOrderStatus(updateOrder: orders): Observable<orders>{
    const url = this.baseURL + "/order/status/" + updateOrder.orderid;
    const headers = new HttpHeaders().set("content-type","application/json");
    return this.http.put<orders>(url, JSON.stringify(updateOrder), {headers: headers})
  }

  //Löscht Consultation aus der DB
  deleteConsultation(consultation: consultations): Observable<any>{
    const url = this.baseURL + "/consultation/" + consultation.consulid;
    const headers = new HttpHeaders().set("content-type","application/json");
    return this.http.delete(url,{headers: headers});
  }

  //Fügt ein Item bei item_hasCategory dazu
  addHasCategory(categoryid: number, itemid: number): Observable<any>{
    const url = this.baseURL + "/hasCategory/" + categoryid + "/" + itemid;
    const headers = new HttpHeaders().set("content-type","application/json");
    return this.http.post(url,{headers: headers});
  }

  //Löscht ein Item aus item_hasCategory
  deleteHasCategory(categoryid: number, itemid: number): Observable<any>{
    const url = this.baseURL + "/hasCategory/" + categoryid + "/" + itemid;
    const headers = new HttpHeaders().set("content-type","application/json");
    return this.http.delete(url,{headers: headers});
  }
}
