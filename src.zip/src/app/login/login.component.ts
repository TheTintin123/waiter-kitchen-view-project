import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {HttpClient} from "@angular/common/http";
import {DbService} from "../db.service";
import {ReadyItemsComponent} from "../waiter/ready-items/ready-items.component";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  hide: boolean = true;
  AuthError: boolean = false;
  httpReqTimer: boolean = false;
  errorMessage: string = "";
  username: string = "";
  password: string = "";
  userControl = new FormControl("", [Validators.required]);
  passwordControl = new FormControl("", [Validators.required]);
  currentUser!:User;

  constructor(private router: Router, private httpClient: HttpClient, private dbService: DbService, private ready:ReadyItemsComponent) {
  }

  //Beim Laden der Seite wird dem Nutzer eine Request-Notification Anfrage geschickt, die dieser Annehmen muss um Push-Notifications zu erhalten
  //Außerdem wird der Session-Storage gelehrt
  ngOnInit(): void {
    this.dbService = new DbService(this.httpClient)
    Notification.requestPermission().then(permission => {
      console.log(permission)
    })
    sessionStorage.clear();
  }

  //Schickt Anfrage an db.service.ts um den Nutzer und das Password in der DB zu überprüfen
  checkLoginUser(user: User) {
    return new Promise(((resolve, reject) => {
      this.dbService
        .getLoginUser(user)
        .subscribe({
          next: (data) => {
            console.log(data);
            if (data.length === 0)
              reject("Wrong User Credentials")
            else {
              this.currentUser.role = data[0].role;
              resolve("Right User");
            }
          }
        })
    }))
  }

  //Disabled den Submit-Button wenn in Username oder Password nichts drinnensteht
  isDisabled():boolean{
    return this.username === "" || this.password === "";
  }

  //Cleared den Username, das Password und die "Wrong User Credentials" Warnung
  reset(){
    this.username = "";
    this.password = "";
    this.AuthError = false;
  }

  //Schickt eine Anfrage an db.service.ts um mithilfe des Nutzers einen JWT zu erstellen und leitet dann anhand der Rolle des Users diesen zu seinem jeweiligen UI weiter
  //Ruft weiters noch die Intervall Funktion aus dem ReadyItems-Component auf, der startet, sobald der Nutzer sich korrekt angemeldet hat
  Submit() {
    this.httpReqTimer = true;

    this.currentUser = {username: this.username, password: this.password, role:""}

    this.checkLoginUser(this.currentUser)
      .then(data => {
        console.log(data)
        this.dbService
          .requestToken(this.currentUser)
          .subscribe({
            next: (data) => {
              console.log(data);
              this.httpReqTimer = false;
              sessionStorage.setItem('userToken', data.accessToken);
              if (this.currentUser.role === "Kitchen")
                this.router.navigate(["dashboard2"])
              else if (this.currentUser.role === "Waiter") {
                this.ready.checkAfterInterval();
                this.router.navigate(["dashboard"])
              }
            }
          })
      }).catch(err => {
        this.httpReqTimer = false;
        this.AuthError = true;
        console.log(err);
        this.errorMessage = err;
      }
    )
  }
}

export interface User{
  username:string;
  password:string;
  role: string;
}
