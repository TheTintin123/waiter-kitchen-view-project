import { NgModule } from '@angular/core';
import {RouterModule, Routes} from "@angular/router";
import {DashboardComponent} from "./dashboard/dashboard.component";
import {OverviewComponent} from "./overview/overview.component";
import {IncompleteComponent} from "./waiter/incomplete/incomplete.component";
import {ConsultComponent} from "./waiter/consult/consult.component";
import {OrdersComponent} from "./waiter/orders/orders.component";
import {ReadyItemsComponent} from "./waiter/ready-items/ready-items.component";
import {Dashboard2Component} from "./dashboard2/dashboard2.component";
import {Overview2Component} from "./overview2/overview2.component";
import {MenuItemsComponent} from "./kitchen/menu-items/menu-items.component";
import {Orders2cookComponent} from "./kitchen/orders2cook/orders2cook.component";
import {ItemSequenceComponent} from "./kitchen/item-sequence/item-sequence.component";
import {LoginComponent} from "./login/login.component";
import {LoginGuardian} from "./login.guardian";

//Zuständig die Routen und ihre Kinder zu definieren
//Jede Route (außer Loginund Dashboard) bekommt einen LoginGuardian, der überprüft ob der JWT valid ist
const routes: Routes = [
  {
    path: "",
    component:LoginComponent
  },
  { path: 'dashboard',
    component: DashboardComponent,
    children:[
      {
        path: "",
        redirectTo: "overview",
        pathMatch: "full"
      },
      {
        path: "overview",
        component: OverviewComponent,
        canActivate: [LoginGuardian]
      },
      {
        path: "incomplete",
        component: IncompleteComponent,
        canActivate: [LoginGuardian]
      },
      {
        path: "consult",
        component: ConsultComponent,
        canActivate: [LoginGuardian]
      },
      {
        path: "orders",
        component: OrdersComponent,
        canActivate: [LoginGuardian]
      },
      {
        path: "readyItems",
        component: ReadyItemsComponent,
        canActivate: [LoginGuardian]
      }
    ]
  },
  {
    path: "dashboard2",
    component: Dashboard2Component,
    children:[
      {
        path: "",
        redirectTo: "overview2",
        pathMatch: "full"
      },
      {
        path: "overview2",
        component: Overview2Component,
        canActivate: [LoginGuardian]
      },
      {
        path: "menuItems",
        component: MenuItemsComponent,
        canActivate: [LoginGuardian]
      },
      {
        path: "orders2cook",
        component: Orders2cookComponent,
        canActivate: [LoginGuardian]
      },
      {
        path: "itemSequence",
        component: ItemSequenceComponent,
        canActivate: [LoginGuardian]
      }
    ]
  },
  {
    path: "**",
    component: LoginComponent
  }
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
