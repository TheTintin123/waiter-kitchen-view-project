import { Component, OnInit } from '@angular/core';
import {DbService} from "../db.service";
import {readyItems} from "../waiter/ready-items/ready-items.component";
import {consultations} from "../waiter/consult/consult.component";
import {orders} from "../waiter/orders/orders.component";

@Component({
  selector: 'app-overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.css']
})
export class OverviewComponent implements OnInit {

  readyItems!: readyItems[];
  consulData!: consultations[];
  ordersData!: orders[];
  incompleteOrdersData!: orders[];


  constructor(private dbService: DbService) {
  }

  //Beim Laden der Seite werden die Getter-Funktionen aufgerufen
  ngOnInit(): void {
    this.dbGetReadyItems();
    this.dbGetConsultations();
    this.dbGetOrders();
  }

  //Schickt Anfrage an db.service.ts um ReadyItems aus der DB zu holen
  dbGetReadyItems(){
    this.dbService.getReadyItems().subscribe((i: readyItems[]) => {
      this.readyItems = i.filter(x => x.status === 'readyForPickup');
    });
  }

  //Schickt Anfrage an db.service.ts um Consultations aus der DB zu holen
  dbGetConsultations(){
    this.dbService.getConsultations().subscribe((i: consultations[]) => {
      this.consulData = i;
    });
  }

  //Schickt Anfrage an db.service.ts um Orders aus der DB zu holen
  dbGetOrders(){
    this.dbService.getOrders().subscribe((i: orders[]) => {
      this.ordersData = i.filter(x => x.status === 'complete');
      this.incompleteOrdersData = i.filter(x => x.status === 'incomplete')
    });
  }


}
