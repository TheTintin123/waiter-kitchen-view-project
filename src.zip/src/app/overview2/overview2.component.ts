import { Component, OnInit } from '@angular/core';
import {DbService} from "../db.service";
import {menuItems} from "../kitchen/menu-items/menu-items.component";
import {items, orders} from "../waiter/orders/orders.component";

@Component({
  selector: 'app-overview2',
  templateUrl: './overview2.component.html',
  styleUrls: ['./overview2.component.css']
})
export class Overview2Component implements OnInit {

  items!: menuItems[];
  orders!: orders[];
  orderedItems!: items[];


  constructor(private dbService: DbService) {
  }

  //Beim Laden der Seite werden die Getter-Funktionen aufgerufen
  ngOnInit(): void {
    this.dbGetItems();
    this.dbGetOrders();
    this.dbGetOrderedItems();
  }

  //Schickt Anfrage an db.service.ts um MenuItems aus der DB zu holen
  dbGetItems(){
    this.dbService.getItems().subscribe((i: menuItems[]) => {
      this.items = i;
    });
  }

  //Schickt Anfrage an db.service.ts um Orders aus der DB zu holen
  dbGetOrders(){
    this.dbService.getOrders().subscribe((i: orders[]) => {
      this.orders = i.filter(x => x.status === 'ordered' || x.status === "incomplete");
    });
  }

  //Schickt Anfrage an db.service.ts um OrderedItems aus der DB zu holen
  dbGetOrderedItems(){
    this.dbService.getOrderedItems().subscribe((i: items[]) => {
      this.orderedItems = i.filter(x => x.status === "ordered" || x.status === "inProduction");
    });
  }

}
