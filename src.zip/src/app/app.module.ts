import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {MaterialImporterModule} from "./material-importer/material-importer.module";
import { HttpClientModule } from "@angular/common/http";

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import { LoginComponent } from './login/login.component';
import {LoginGuardian} from "./login.guardian";

import { DashboardComponent } from './dashboard/dashboard.component';
import { OverviewComponent } from './overview/overview.component';
import { OrdersComponent } from './waiter/orders/orders.component';
import { ConsultComponent } from './waiter/consult/consult.component';
import { IncompleteComponent } from './waiter/incomplete/incomplete.component';
import { ReadyItemsComponent } from './waiter/ready-items/ready-items.component';

import { Dashboard2Component } from './dashboard2/dashboard2.component';
import { Overview2Component } from './overview2/overview2.component';
import { MenuItemsComponent } from './kitchen/menu-items/menu-items.component';
import { Orders2cookComponent } from './kitchen/orders2cook/orders2cook.component';
import { ItemSequenceComponent } from './kitchen/item-sequence/item-sequence.component';
import { ItemSequenceComponentDialog} from "./kitchen/item-sequence/item-sequence.component";


//Importiert und aktiviert alle notwendigen Module und Komponenten
@NgModule({
  declarations: [
    AppComponent,
    OrdersComponent,
    MenuItemsComponent,
    DashboardComponent,
    OverviewComponent,
    ConsultComponent,
    IncompleteComponent,
    ReadyItemsComponent,
    Dashboard2Component,
    Overview2Component,
    Orders2cookComponent,
    ItemSequenceComponent,
    ItemSequenceComponentDialog,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MaterialImporterModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [LoginGuardian, ReadyItemsComponent],
  bootstrap: [AppComponent]
})

export class AppModule {}
