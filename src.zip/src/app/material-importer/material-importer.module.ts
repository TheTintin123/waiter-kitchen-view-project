import { NgModule } from '@angular/core';

import {MatSidenavModule} from "@angular/material/sidenav";
import {MatButtonModule} from "@angular/material/button";
import {MatListModule} from "@angular/material/list";
import {MatDividerModule} from "@angular/material/divider";
import {MatCardModule} from "@angular/material/card";
import {MatIconModule} from "@angular/material/icon";
import {MatTableModule} from "@angular/material/table";
import {MatExpansionModule} from "@angular/material/expansion";
import {MatFormFieldModule} from "@angular/material/form-field";
import {MatButtonToggleModule} from "@angular/material/button-toggle";
import {MatDialogModule} from "@angular/material/dialog";
import {MatCheckboxModule} from "@angular/material/checkbox";
import {MatInputModule} from "@angular/material/input";
import {MatProgressBarModule} from "@angular/material/progress-bar";
import {MatToolbarModule} from '@angular/material/toolbar';

//Mithilfe dieser Datei importiere ich alle Angular Material Module
//So muss ich nicht alles in die app.module Datei packen
const MaterialComponents = [
  MatSidenavModule,
  MatButtonModule,
  MatDividerModule,
  MatListModule,
  MatCardModule,
  MatIconModule,
  MatTableModule,
  MatExpansionModule,
  MatFormFieldModule,
  MatButtonToggleModule,
  MatDialogModule,
  MatCheckboxModule,
  MatInputModule,
  MatProgressBarModule,
  MatToolbarModule
]

@NgModule({
  imports: [MaterialComponents],
  exports: [MaterialComponents]
})

export class MaterialImporterModule { }
