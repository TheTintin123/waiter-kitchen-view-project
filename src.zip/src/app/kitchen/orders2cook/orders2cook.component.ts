import { Component, OnInit } from '@angular/core';
import {items, orders} from "../../waiter/orders/orders.component";
import {DbService} from "../../db.service";
import {IncompleteComponent} from "../../waiter/incomplete/incomplete.component";


@Component({
  selector: 'app-orders2cook',
  templateUrl: './orders2cook.component.html',
  styleUrls: ['./orders2cook.component.css']
})
export class Orders2cookComponent implements OnInit {

  panelOpenState = false;
  itemsData!: items[];
  items!: items[];
  ordersData!: orders[];

  constructor(private dbService: DbService) {
  }

  //Beim Laden der Seite werden die OrderedItems und die Orders aus der DB geholt
  ngOnInit(): void {
    this.dbGetOrderedItems().then(data => {
      console.log(data)
      this.dbGetOrders();
    });
  }

  //Überprüft, welche OrderedItems in welcher Order sind und ob der Status der Items ordered oder inProduction ist
  checkHasItems(currentOrder: orders): boolean{
    let hasItems = false;
    for(let i = 0; i < this.itemsData.length; i++) {
      if (currentOrder.orderid == this.itemsData[i].orderid)
        if (this.itemsData[i].status == "ordered" || this.itemsData[i].status == "inProduction") {
           hasItems = true;
          break;
        }
    }
    return hasItems;
  }

  //Schickt Anfrage an db.service.ts um OrderedItems aus der DB zu holen
  dbGetOrderedItems(){
    return new Promise(resolve => {
      this.dbService.getOrderedItems().subscribe((i: items[]) => {
        this.items = i;
        this.itemsData = i.filter(x => x.status === 'ordered' || x.status === 'inProduction');
        resolve("Got all Items");
      });
    })
  }

  //Schickt Anfrage an db.service.ts um Orders aus der DB zu holen
  dbGetOrders(){
    this.dbService.getOrders().subscribe((i: orders[]) => {
      i.forEach(x => this.checkOrderState(x));
      this.ordersData = i.filter(x => x.status === 'ordered' || (x.status === "incomplete" && this.checkHasItems(x)));
    });
  }

  //Überprüft bei jeder Orden den Status und ändert ihn gegebenfalls
  checkOrderState(currentOrder: any) {
    let currentStatus: string = "ordered";
    let orderedItemsCounter: number = 0;
    let deliveredItemsCounter: number = 0;
    for (let i = 0; i < this.items.length; i++) {
      if (this.items[i].orderid == currentOrder.orderid) {
        orderedItemsCounter++;
        if (this.items[i].status == "readyForPickup" || this.items[i].status == "inTransit") {
          currentStatus = "incomplete";
          break;
        } else if (this.items[i].status == "delivered")
          deliveredItemsCounter++;
      }
    }
    if(deliveredItemsCounter > 0)
      currentStatus = 'incomplete';
    if (deliveredItemsCounter == orderedItemsCounter)
      currentStatus = 'complete';
    currentOrder.status = currentStatus;
    this.dbService.updateOrderStatus(currentOrder).subscribe((i: orders) => {
      console.log(i);
    })
  }

  //Überprüft ob der Button InProduction disabled ist oder nicht
  buttonState1(currentElement: any):boolean{
    return currentElement.status == "inProduction";
  }

  //Überprüft ob der Button ReadyForPickup disabled ist oder nicht
  buttonState2(currentElement: any):boolean{
    return currentElement.status == "readyForPickup";
  }

  //Auf Knopfdruck wird eine Funktion in der db.service.ts aufgerufen, die den Status des jeweiligen Items in der DB ändert
  //Gleichzeitig werden die Items und Orders neu geladen
  updateStatus(button: number, currentElement: any){
    if(button == 1)
      currentElement.status = "readyForPickup"
    else
      currentElement.status = "inProduction"
    console.log(currentElement);
    this.dbService.updateOrderedItemStatus(currentElement).subscribe((i: items) => {
      console.log(i);
    })
    if (button == 1) {
      setTimeout(()=>{
        this.dbGetOrderedItems().then(data => {
          console.log(data);
          this.dbGetOrders();
        });
      },300)
    }
  }

}
