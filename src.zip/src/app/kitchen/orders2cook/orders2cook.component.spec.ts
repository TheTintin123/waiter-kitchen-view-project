import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Orders2cookComponent } from './orders2cook.component';

describe('Orders2cookComponent', () => {
  let component: Orders2cookComponent;
  let fixture: ComponentFixture<Orders2cookComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Orders2cookComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Orders2cookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
