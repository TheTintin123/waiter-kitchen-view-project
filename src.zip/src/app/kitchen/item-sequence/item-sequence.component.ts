import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from "@angular/material/dialog";
import {MatTable} from "@angular/material/table";
import {DbService} from "../../db.service";
import {items} from "../../waiter/orders/orders.component";

@Component({
  selector: 'app-item-sequence',
  templateUrl: './item-sequence.component.html',
  styleUrls: ['./item-sequence.component.css']
})

export class ItemSequenceComponent implements OnInit {

  itemSeqData!: items[];

  constructor(private dbService: DbService, public dialog: MatDialog) {
  }

  @ViewChild(MatTable) myTable!: MatTable<any>;

  //Beim Laden der Seite werden die OrderedItems aus der DB geholt
  ngOnInit(): void {
    this.dbGetOrderedItems().then( data => {
      console.log(data)
    });
  }

  //Schickt Anfrage an db.service.ts um OrderedItems aus der DB zu holen
  dbGetOrderedItems(){
    return new Promise(resolve => {
      this.dbService.getOrderedItems().subscribe((i: items[]) => {
        this.itemSeqData = i.filter(x => x.status === 'ordered');
        resolve("Got all orderedItems!")
      })
    })
  }

  //Aktualisiert den Comment in der DB
  dbUpdateItemComment(currentElement:any){
    return new Promise( resolve => {
      this.dbService.updateOrderedItemComment(currentElement).subscribe( (i:items) => {
        resolve(i);
      })
    })
  }

  //Öffnet das Inputfeld für den Comment mit dem bisherigen Comment
  //Wird ok gedrückt, wird der Comment auf den Value des Inputfeldes gesetzt und der Comment in der DB aktualisiert
  openDialog(row: any): void {
    let dialogRef = this.dialog.open(ItemSequenceComponentDialog, {
      width: '250px',
      data: {comment: row.comment}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.itemSeqData.forEach(e => {
        if(e == row) {
          e["comment"] = result;
          this.dbUpdateItemComment(e).then( data => {
            console.log(data);
            })
        }})
    });
  }

  //Aktualisiert den Table
  update(): void{
    this.myTable.renderRows();
  }

  //Schiebt ein Element in der Liste nach oben
  moveUp(element: items){
    let position: number = this.itemSeqData.indexOf(element);
    let help: items = this.itemSeqData[position-1];
    this.itemSeqData[position-1] = this.itemSeqData[position];
    this.itemSeqData[position] = help;
    this.update();
    }

  //Schiebt ein Element in der Liste nach unten
  moveDown(element: items){
    let position: number = this.itemSeqData.indexOf(element);
    let help: items = this.itemSeqData[position+1];
    this.itemSeqData[position+1] = this.itemSeqData[position];
    this.itemSeqData[position] = help;
    this.update();
  }

  //Disabled den obersten Button
  buttonState1(currentElement: any):boolean{
    return this.itemSeqData.indexOf(currentElement)==0;
  }

  //Disabled den untersten Button
  buttonState2(currentElement: any):boolean{
    return this.itemSeqData.indexOf(currentElement)==this.itemSeqData.length-1;
  }

  displayedColumns: string[] = ["rank","title","orderId","comment","updateComment", "positionUp", "positionDown"];
}

@Component({
  selector: 'item-sequence.component.dialog',
  templateUrl: 'item-sequence.component.dialog.html',
  styleUrls: ['./item-sequence.component.dialog.css']
})

//Klasse für den geöffneten Dialog
export class ItemSequenceComponentDialog {
  constructor(
    public dialogRef: MatDialogRef<ItemSequenceComponentDialog>,
    @Inject(MAT_DIALOG_DATA) public data: items,
  ) {}

  //Schließt das Dialogfeld
  onNoClick(): void {
    this.dialogRef.close();
  }
}
