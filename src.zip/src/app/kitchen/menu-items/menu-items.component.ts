import {Component, Input, OnInit} from '@angular/core';
import {DbService} from "../../db.service";

export interface menuItems{
  id: number;
  title: string;
  status: string;
}

export interface category{
  categoryid: number;
  title: string;
}

export interface hasCategory{
  categoryid: number;
  itemid: number;
}

@Component({
  selector: 'app-menu-items',
  templateUrl: './menu-items.component.html',
  styleUrls: ['./menu-items.component.css']
})
export class MenuItemsComponent implements OnInit {

  @Input()
  itemId!: number;
  menuItemsData!: menuItems[];
  categories!: category[];
  hasCategoryList!: hasCategory[];

  constructor(private dbService: DbService) {
  }

  ngOnInit(): void {
    this.dbGetMenuItems();
    this.dbGetCategories();
    this.dbHasCategories()
  }

  //Schickt Anfrage an db.service.ts um MenuItems aus der DB zu holen
  dbGetMenuItems(){
      this.dbService.getItems().subscribe((i: menuItems[]) => {
        this.menuItemsData = i;
    })
  }

  //Schickt Anfrage an db.service.ts um Categories aus der DB zu holen
  dbGetCategories(){
      this.dbService.getCategories().subscribe((i: category[]) => {
        this.categories = i;
    })
  }

  //Schickt Anfrage an db.service.ts um item_HasCategories aus der DB zu holen
  dbHasCategories(){
      this.dbService.getHasCategoryList().subscribe((i: hasCategory[]) => {
        this.hasCategoryList = i;

      })
    }

  displayedColumns: string[] = ["id", "title","status", "category"];
  displayedFooter: string[] = ["id","title"];

  //Überprüft, ob ein Items zu einer Categorie gehört oder nicht
   checkHasCategory(categoryid: number, itemid: number):any {
      if(this.hasCategoryList === undefined)
        this.dbHasCategories()
      else
        for (let i = 0; i < this.hasCategoryList.length; i++) {
          if (this.hasCategoryList[i].categoryid == categoryid && this.hasCategoryList[i].itemid == itemid)
            return true;
        }
        return false
     }

  //Beim Klick auf ein Kategoriekästchen wird überprüft, ob es gehakt ist oder nicht und added oder löscht es sonst aus der DB
  onChange(categoryid: number, itemid: number, event:any){
    if(event.checked)
      this.dbService.addHasCategory(categoryid, itemid).subscribe((i: hasCategory) => {
        console.log(i);
      })
    else
      this.dbService.deleteHasCategory(categoryid, itemid).subscribe((i: hasCategory) => {
        console.log(i);
      })
  }

  //Überprüft ob der Button available disabled ist
  buttonState1(button: number, currentElement: any):boolean{
    return currentElement.status == "available";
  }

  //Überprüft ob der Button not available disabled ist
  buttonState2(button: number, currentElement: any):boolean{
    return currentElement.status == "unavailable";
  }

  //Beim Klicken eines der Buttons wird der Status des MenuItems in der DB geändert
  clickButton(button: number, currentElement: any){
    if(button == 1)
      currentElement.status = "unavailable"
    else
      currentElement.status = "available"

    this.dbService.updateMenuItemStatus(currentElement).subscribe((i: menuItems) => {
      console.log(i);
    })
  }
}
