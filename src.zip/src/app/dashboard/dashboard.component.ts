import {Component, OnInit, ViewChild} from '@angular/core';
import {Router} from "@angular/router";
import {BreakpointObserver} from '@angular/cdk/layout';
import { MatSidenav} from '@angular/material/sidenav';
import {ReadyItemsComponent} from "../waiter/ready-items/ready-items.component";

@Component({
  selector: 'app-dashboard',
  templateUrl: 'dashboard.component.html',
  styleUrls: ['dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  @ViewChild(MatSidenav)
  sidenav!: MatSidenav;

  constructor(private router:Router, private observer: BreakpointObserver, private ready: ReadyItemsComponent) {
  }

  ngOnInit(): void {
  }
  opened = true;

  //Beim Klick auf LogOut wird man zum Login weitergeleitet
  //Der JWT wird aus dem Session-Storage gelöscht
  //Stoppt das Intervall
  logOut(){
    this.router.navigate([""]);
    sessionStorage.removeItem("userToken")
    this.ready.destroyChecker();
    console.log("You have been logged out!")
  }

  //Überprüft die Breite des Fenster
  //Ist das Fenster <= 600px wird das dynamische Design aktiviert
  ngAfterViewInit() {
    this.observer.observe(['(max-width: 600px)']).subscribe((res) => {
      if (res.matches) {
        this.sidenav.mode = 'over';
        this.sidenav.close();
      } else {
        this.sidenav.mode = 'side';
        this.sidenav.open();
      }
    });
  }
}
